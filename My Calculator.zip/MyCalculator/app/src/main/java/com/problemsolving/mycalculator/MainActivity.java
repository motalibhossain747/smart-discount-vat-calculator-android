package com.problemsolving.mycalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.internal.TextWatcherAdapter;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText etPrice, etDiscount, etVat;
    Button btnCalculate, AllClear;
    TextView tvResult;
    Animation fadeIn, scaleUp;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //==========================================================================================
        etPrice = findViewById(R.id.etPrice);
        etDiscount = findViewById(R.id.etDiscount);
        etVat = findViewById(R.id.etVat);
        //btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
        AllClear = findViewById(R.id.btnAllClear);

        fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        scaleUp = AnimationUtils.loadAnimation(this, R.anim.scale_up);
        //=================================================

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculateLive();
            }
        };

        etPrice.addTextChangedListener(textWatcher);
        etDiscount.addTextChangedListener(textWatcher);
        etVat.addTextChangedListener(textWatcher);
        //=========================================================================================
        /*btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String priceStr = etPrice.getText().toString();
                String discountStr = etDiscount.getText().toString();
                String vatStr = etVat.getText().toString();

                if (priceStr.isEmpty() || discountStr.isEmpty() || vatStr.isEmpty()) {
                    tvResult.setText("Please fill all fields!");
                    return;
                }

                double price = Double.parseDouble(priceStr);
                double discount = Double.parseDouble(discountStr);
                double vat = Double.parseDouble(vatStr);

                // Step 1: Discount apply
                double afterDiscount = price - (price * discount / 100);

                // Step 2: VAT add
                double finalPrice = afterDiscount + (afterDiscount * vat / 100);

                tvResult.setText("Result: " + finalPrice);

                // Start Animations
                tvResult.startAnimation(scaleUp);
                tvResult.startAnimation(fadeIn);
            }
        });*/
        //=========================================================================================
        AllClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etPrice.setText("");
                etDiscount.setText("");
                etVat.setText("");
                tvResult.setText("Result: --");

            }
        });

    }//==============================================================================================

    private void calculateLive() {
        String priceStr = etPrice.getText().toString().trim();
        String discountStr = etDiscount.getText().toString().trim();
        String vatStr = etVat.getText().toString().trim();

        if (priceStr.isEmpty()) {
            tvResult.setText("Result: 0.00");
            return;
        }

        double price = Double.parseDouble(priceStr);
        double discount = discountStr.isEmpty() ? 0 : Double.parseDouble(discountStr);
        double vat = vatStr.isEmpty() ? 0 : Double.parseDouble(vatStr);

        // price → apply discount
        double afterDiscount = price - (price * (discount / 100));

        // after discount → apply VAT
        double finalPrice = afterDiscount + (afterDiscount * (vat / 100));

        //tvResult.setText("Result: " + String.format("%.2f", finalPrice));

        tvResult.setText("Result: " + String.format(Locale.US, "%.2f", finalPrice));

    }


}//==================================================================================================